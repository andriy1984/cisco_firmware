if(parent.pdfUrl != "")
{
theMenu.addChild(-1, "Document", parent.pdf , parent.pdfUrl, parent.pdf , parent.pdfTarget);
}

if(parent.glossaryUrl != "")
{
theMenu.addChild(-1, "Document", parent.glossary , parent.glossaryUrl, parent.glossary, parent.glossaryTarget);
}