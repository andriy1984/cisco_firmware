if(!mapSet)
{
var mapSet = new Array();
}

//########################
// filename:  IPCmapping.hlp
// application:  Cisco IP Communicator Online Help
// 
//Copyright (c) 2004 by Cisco Systems,Inc.
//All rights reserved                        
//########################
// 

//Search scope

//################################
// Following are the context-sensitive links
//
//################################
// User Settings
mapSet[mapSet.length] = "prefuser /output/ipc48.html#1005548";

// Network Settings
mapSet[mapSet.length] = "prefnetwrk /output/ipc49.html#1005618";

// Audio Settings
mapSet[mapSet.length] = "prefaudio /output/ipc410.html#1005676";

// Network Audio Settings
mapSet[mapSet.length] = "netaudio /output/ipc412.html#1005852";

// Advanced Audio Settings
mapSet[mapSet.length] = "advaudio /output/ipc413.html#1005902";

// Directories Settings
mapSet[mapSet.length] = "prefdirs /output/ipc414.html#1006006";

// Using the Quick Search Feature
mapSet[mapSet.length] = "qsearch /output/ipc64.html#1005480";

